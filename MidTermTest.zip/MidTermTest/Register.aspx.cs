﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MidTermTest
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            DataAccessLayer dao = new DataAccessLayer();
           
                dao.insertUser(txtUserId.Text, txtName.Text, txtPassword.Text, txtConfirmPassword.Text, txtEmailId.Text);
                txtMessage.Visible = true;
                txtMessage.Text = "User Successfully registered";
                Response.Redirect("Login.aspx");
           
               
        }
    }
}